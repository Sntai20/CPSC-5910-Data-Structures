// TOOO: CalculatorIO implementation goes in this file.
#include <iostream>
#include <fstream>
#include "CalculatorIO.h"
#include <vector>
using namespace std;


void CalculatorIO::CalculateFile(const std::string& inputFilePath, const std::string& outputFilePath){
    //Calculator calc;
    vector < string > v;
    double num1, num2;
    string op;
    ifstream myInputFile;
    myInputFile.open(inputFilePath, ios::out);
    ofstream myOutputFile;
    myOutputFile.open(outputFilePath, ios::out | ios::app | ios::binary);

    while(!myInputFile.eof()){
        //add to vector, split by space
        string line;
        while(getline(myInputFile, line, ' ')){
            v.push_back(line);
        }
    }
    for(auto & i : v) {
        int j = 0;
        while(j != 3) {
            if (i == "[0-9]") {
                if (num1 == 0.0 ) {
                    num1 = stod(i);
                    std::cout << num1;
                } else {
                    num2 = stod(i);
                    std::cout << num2;
                }
            } else if (i == "[+-*/]") {
                op = i;
            }
            j++;
        }
        if(op == "+"){
            myOutputFile << calc.Add(num1,num2);
        }
        else if(op == "-"){
            myOutputFile << calc.Subtract(num1,num2);
        }
        else if(op == "*"){
            myOutputFile << calc.Multiply(num1,num2);
        }
        else if(op == "/"){
            myOutputFile << calc.Divide(num1,num2);
        }
    }
}